# kkdbs

## 数据库连接池

```angular2html
1. Mysql 连接池 ✅
2. Redis 连接池
```