
#
# Copyright vekair
#
__version__ = '0.1.0'
__VERSION__ = __version__
from .mysql_execute import MysqlExecute